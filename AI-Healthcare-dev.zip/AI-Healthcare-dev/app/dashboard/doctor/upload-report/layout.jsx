export const metadata = {
  title: "Upload Patient Report - MEDIRA",
  description: "Upload and analyze patient medical reports and images with AI",
};

export default function UploadReportLayout({ children }) {
  return children;
}

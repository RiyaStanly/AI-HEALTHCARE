export const metadata = {
  title: "Doctor Dashboard - MEDIRA",
  description:
    "Enhance clinical decision-making with MEDIRA's AI-powered tools",
};

export default function DoctorDashboardLayout({ children }) {
  return children;
}

export const metadata = {
  title: "Dashboard - MEDIRA",
  description: "Access your MEDIRA healthcare dashboard",
};

export default function DashboardLayout({ children }) {
  return children;
}

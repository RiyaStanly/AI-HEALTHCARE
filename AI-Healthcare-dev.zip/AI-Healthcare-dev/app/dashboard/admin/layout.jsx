export const metadata = {
  title: "Admin Dashboard - MEDIRA",
  description: "Manage MEDIRA platform and users",
};

export default function AdminDashboardLayout({ children }) {
  return children;
}

export const metadata = {
  title: "User Dashboard - MEDIRA",
  description:
    "Manage your health with MEDIRA's intelligent diagnostics and personalized recommendations",
};

export default function PatientDashboardLayout({ children }) {
  return children;
}

export const metadata = {
  title: "Medical Records - MEDIRA",
  description: "View and manage your medical records and test results",
};

export default function MedicalRecordsLayout({ children }) {
  return children;
}

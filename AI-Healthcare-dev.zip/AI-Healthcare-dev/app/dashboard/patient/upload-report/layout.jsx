export const metadata = {
  title: "Upload Medical Report - MEDIRA",
  description: "Upload and analyze medical images or lab reports using AI",
};

export default function UploadReportLayout({ children }) {
  return children;
}
